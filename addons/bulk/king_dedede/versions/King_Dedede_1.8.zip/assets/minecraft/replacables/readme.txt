Hullo random mineman, this is CodePixel speaking to you from within a few files in the Dedede pack.

This is a small instruction manual on how to use the replaceable files.
The purpose of replaceable files are just meant to be slight alterations to the pack, if you should choose to use them.

For this pack I’ve included two replaceable files, a texture and a sound.

1. Alt. Armor (Original Design)
The Dedede armor’s first version. Lacks yellow hands, and whatever that shirt/robe thing Dedede wears in smash 4.

It’s titled bulk1o.png

In order to replace this file, copy it, then from assets go to:
mcpatcher > cit > heroes > bulk

From here, paste in the file and take out the old bulk1o.png. DO NOT TOUCH THE REGULAR bulk1.png. This isn’t what you’re looking for.

Once you’ve done that, go back in-game and enjoy the original ripped penguin man.
If you ever want to use the normal armor again, be sure to take out and save the .png before replacing.

2. Alt. Smash Activation Sound (Ima clobber that there Kirby)
CrypticMemes wanted to put this in incredibly badly, but I wasn’t sure, as it kinda sounded odd along with the rest of Smash 4 Dedede sounds. In case you want to see what it sounded like for yourself though, we’ve included it for you to test around with.

It should be named crystal.ogg

In order to use this sound, go back to assets > sounds > Bulk, and replace the current crystal.ogg with the new one.

From now on, you’ll hear dedede clobba’in that there Kirby.

Enjoy the pack. 
Special thanks to CrypticMemes for his help with it.

Ciao
-Code
